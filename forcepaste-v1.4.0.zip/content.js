// ForcePaste & Shield Content Script
// Handles Human Typing, Floating Badges, Offscreen Clipboard,
// Vocabulary/Thesaurus Helper, Text Staging, and Unblocking Controllers.

(() => {
  if (window.__FORCEPASTE_CONTENT_INITIALIZED__) return;
  window.__FORCEPASTE_CONTENT_INITIALIZED__ = true;

  // Settings cache
  let settings = {
    enabled: true,
    speedMode: "custom", // custom, human, fast, instant
    baseDelay: 25,
    customWPM: 60,
    showFloatingIcon: true,
    naturalJitter: true,
    autoUnblock: false,
    alwaysActive: false,
    forceSelect: false,
    vocabHelper: true,
    stagedText: ""
  };

  // State
  let activeElement = null;
  let isTyping = false;
  let abortTyping = false;
  let hideTimeout = null;
  let currentRestrictions = null;
  let selectedWord = "";

  // Load settings
  chrome.storage.local.get(null, (res) => {
    if (res) {
      settings = { ...settings, ...res };
      syncProbeFeatures();
    }
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local") {
      for (const [key, change] of Object.entries(changes)) {
        settings[key] = change.newValue;
      }
      syncProbeFeatures();
      if (!settings.showFloatingIcon || !settings.enabled) {
        hideButton();
      }
    }
  });

  function syncProbeFeatures() {
    window.postMessage({ type: "HT_SET_UNBLOCK_STATE", key: "alwaysActive", unblock: !!settings.alwaysActive }, "*");
    window.postMessage({ type: "HT_SET_UNBLOCK_STATE", key: "selection", unblock: !!settings.forceSelect }, "*");
  }

  // Listen for restrictions updates from page-probe.js (MAIN world)
  window.addEventListener("message", (e) => {
    if (!e.data || e.data.type !== "HT_RESTRICTIONS_UPDATE") return;
    currentRestrictions = e.data.restrictions;

    if (settings.autoUnblock) {
      window.postMessage({ type: "HT_SET_UNBLOCK_STATE", key: "all", unblock: true }, "*");
    }
  });

  // Handle messages from Popup or Background
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === "GET_PAGE_RESTRICTIONS") {
      sendResponse({ restrictions: currentRestrictions });
      return true;
    }

    if (msg.type === "TOGGLE_UNBLOCK") {
      window.postMessage({
        type: "HT_SET_UNBLOCK_STATE",
        key: msg.key,
        unblock: msg.unblock
      }, "*");
      sendResponse({ success: true });
      return true;
    }

    if (msg.type === "TRIGGER_PASTE") {
      performPaste();
      sendResponse({ success: true });
      return true;
    }

    if (msg.type === "TYPE_STAGED_TEXT") {
      const target = activeElement || (isEditable(document.activeElement) ? document.activeElement : null);
      if (target && msg.text) {
        typeTextIntoElement(target, msg.text);
      }
      sendResponse({ success: true });
      return true;
    }

    if (msg.type === "SHOW_DEFINITION") {
      if (msg.word) {
        showVocabModal(msg.word, window.innerWidth / 2 - 160, 100);
      }
      sendResponse({ success: true });
      return true;
    }
  });

  // Create isolated Shadow DOM Host
  const host = document.createElement("div");
  host.id = "__forcepaste_host__";
  host.style.all = "initial";
  const shadow = host.attachShadow({ mode: "open" });

  // Styles inside Shadow DOM
  const style = document.createElement("style");
  style.textContent = `
    * {
      box-sizing: border-box;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    }

    #ht-button-container {
      position: absolute;
      z-index: 2147483647;
      display: none;
      align-items: center;
      gap: 4px;
      pointer-events: auto;
      transition: opacity 0.15s ease, transform 0.15s ease;
      opacity: 0;
      transform: translateY(2px) scale(0.96);
      user-select: none;
    }

    #ht-button-container.ht-visible {
      display: flex;
      opacity: 1;
      transform: translateY(0) scale(1);
    }

    .ht-btn {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      padding: 4px 9px;
      height: 26px;
      font-size: 11px;
      font-weight: 700;
      color: #ffffff;
      background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 6px;
      cursor: pointer;
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15), 0 1px 2px rgba(0, 0, 0, 0.1);
      transition: all 0.12s ease;
      line-height: 1;
    }

    .ht-btn:hover {
      background: linear-gradient(135deg, #4338ca 0%, #6d28d9 100%);
      box-shadow: 0 3px 8px rgba(79, 70, 229, 0.35);
      transform: translateY(-1px);
    }

    .ht-btn.ht-stop {
      background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
    }

    .ht-btn svg {
      width: 12px;
      height: 12px;
      fill: currentColor;
      flex-shrink: 0;
    }

    /* Fallback prompt dialog */
    #ht-dialog-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.35);
      backdrop-filter: blur(2px);
      z-index: 2147483647;
      display: none;
      align-items: center;
      justify-content: center;
    }

    #ht-dialog {
      background: #ffffff;
      padding: 18px;
      border-radius: 12px;
      box-shadow: 0 10px 25px rgba(0,0,0,0.25);
      width: 340px;
      max-width: 92vw;
      color: #1f2937;
    }

    #ht-dialog h3 {
      margin: 0 0 8px 0;
      font-size: 14px;
      font-weight: 600;
      color: #111827;
      display: flex;
      align-items: center;
      gap: 6px;
    }

    #ht-dialog p {
      margin: 0 0 10px 0;
      font-size: 12px;
      color: #4b5563;
      line-height: 1.4;
    }

    #ht-dialog textarea {
      width: 100%;
      height: 85px;
      border: 1.5px solid #c7d2fe;
      border-radius: 8px;
      padding: 10px;
      font-size: 12px;
      font-family: inherit;
      resize: vertical;
      outline: none;
      color: #1f2937;
      background: #fafafa;
    }

    .ht-dialog-actions {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-top: 12px;
    }

    .ht-dialog-actions-right {
      display: flex;
      gap: 8px;
    }

    .ht-dialog-actions button {
      padding: 6px 12px;
      font-size: 12px;
      font-weight: 600;
      border-radius: 6px;
      cursor: pointer;
      border: none;
      display: inline-flex;
      align-items: center;
      gap: 4px;
    }

    .ht-btn-clip {
      background: #e0e7ff;
      color: #4338ca;
    }

    .ht-btn-cancel {
      background: #f3f4f6;
      color: #374151;
    }

    .ht-btn-confirm {
      background: #4f46e5;
      color: #ffffff;
    }

    /* 4th: VOCABULARY / THESAURUS HELPER UI */
    #fp-define-badge {
      position: absolute;
      z-index: 2147483647;
      display: none;
      align-items: center;
      gap: 4px;
      padding: 4px 10px;
      height: 26px;
      background: #111827;
      color: #ffffff;
      font-size: 11px;
      font-weight: 700;
      border-radius: 14px;
      box-shadow: 0 4px 14px rgba(0,0,0,0.3);
      cursor: pointer;
      border: 1px solid rgba(255,255,255,0.2);
      transition: transform 0.12s ease;
      user-select: none;
      pointer-events: auto;
    }

    #fp-define-badge:hover {
      background: #1f2937;
      transform: scale(1.05);
    }

    #fp-define-badge svg {
      width: 12px;
      height: 12px;
      fill: #a5b4fc;
    }

    /* Floating Vocab Card (Dark Theme matching screenshots) */
    #fp-vocab-card {
      position: absolute;
      z-index: 2147483647;
      width: 330px;
      max-width: 92vw;
      max-height: 440px;
      background: #181d24;
      color: #e2e8f0;
      border-radius: 12px;
      box-shadow: 0 14px 35px rgba(0,0,0,0.45);
      border: 1px solid #2d3748;
      padding: 14px 16px;
      display: none;
      font-size: 12px;
      overflow-y: auto;
      pointer-events: auto;
    }

    .fp-card-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-bottom: 1px solid #2d3748;
      padding-bottom: 10px;
      margin-bottom: 10px;
    }

    .fp-card-title-row {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .fp-speaker-btn {
      width: 28px;
      height: 28px;
      border-radius: 50%;
      background: #3b82f6;
      border: none;
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      transition: transform 0.1s ease, background 0.1s ease;
      flex-shrink: 0;
    }

    .fp-speaker-btn:hover {
      background: #2563eb;
      transform: scale(1.08);
    }

    .fp-speaker-btn svg {
      width: 14px;
      height: 14px;
      fill: currentColor;
    }

    .fp-word-title {
      font-size: 15px;
      font-weight: 700;
      color: #ffffff;
    }

    .fp-word-phonetic {
      font-size: 11px;
      color: #94a3b8;
      margin-left: 2px;
    }

    .fp-close-btn {
      background: transparent;
      border: none;
      color: #94a3b8;
      font-size: 16px;
      cursor: pointer;
      line-height: 1;
      padding: 4px;
    }

    .fp-close-btn:hover {
      color: #ffffff;
    }

    .fp-section-title {
      font-size: 12px;
      font-weight: 700;
      color: #60a5fa;
      margin-top: 10px;
      margin-bottom: 5px;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }

    .fp-part-of-speech {
      display: inline-block;
      font-size: 10px;
      font-weight: 700;
      text-transform: uppercase;
      padding: 1px 6px;
      border-radius: 4px;
      background: #334155;
      color: #cbd5e1;
      margin-right: 6px;
    }

    .fp-definition-item {
      margin-bottom: 8px;
      line-height: 1.45;
      color: #cbd5e1;
      font-size: 12px;
    }

    .fp-example {
      font-size: 11px;
      font-style: italic;
      color: #94a3b8;
      margin-top: 2px;
      border-left: 2px solid #475569;
      padding-left: 6px;
    }

    .fp-synonyms-wrap {
      display: flex;
      flex-wrap: wrap;
      gap: 5px;
      margin-top: 6px;
    }

    .fp-synonym-pill {
      background: #1e293b;
      color: #93c5fd;
      border: 1px solid #3b82f6;
      border-radius: 12px;
      padding: 2px 8px;
      font-size: 11px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.1s ease;
    }

    .fp-synonym-pill:hover {
      background: #3b82f6;
      color: #ffffff;
      transform: translateY(-1px);
    }

    .fp-copied-toast {
      font-size: 10px;
      color: #34d399;
      font-weight: 600;
    }
  `;

  // UI elements inside shadow root
  const container = document.createElement("div");
  container.id = "ht-button-container";

  const pasteBtn = document.createElement("button");
  pasteBtn.className = "ht-btn";
  pasteBtn.title = "ForcePaste with Human Typing (Alt+V)";
  pasteBtn.innerHTML = `
    <svg viewBox="0 0 24 24"><path d="M19 2h-4.18C14.4 0.84 13.3 0 12 0c-1.3 0-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-7 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm7 18H5V4h2v3h10V4h2v16z"/></svg>
    <span class="ht-label">ForcePaste</span>
  `;
  container.appendChild(pasteBtn);

  // Fallback modal dialog
  const dialogOverlay = document.createElement("div");
  dialogOverlay.id = "ht-dialog-overlay";
  dialogOverlay.innerHTML = `
    <div id="ht-dialog">
      <h3>
        <svg style="width:16px;height:16px;fill:#4f46e5;" viewBox="0 0 24 24"><path d="M19 2h-4.18C14.4 0.84 13.3 0 12 0c-1.3 0-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-7 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm7 18H5V4h2v3h10V4h2v16z"/></svg>
        ForcePaste - Auto-Type Text
      </h3>
      <p>Paste text below (Ctrl+V works here) or click <b>Paste from Clipboard</b>:</p>
      <textarea id="ht-modal-textarea" placeholder="Paste text here (Ctrl+V works)..."></textarea>
      <div class="ht-dialog-actions">
        <button class="ht-btn-clip" id="ht-btn-fetch-clip">
          <svg style="width:12px;height:12px;fill:currentColor" viewBox="0 0 24 24"><path d="M19 2h-4.18C14.4 0.84 13.3 0 12 0c-1.3 0-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/></svg>
          Paste from Clipboard
        </button>
        <div class="ht-dialog-actions-right">
          <button class="ht-btn-cancel">Cancel</button>
          <button class="ht-btn-confirm">Start Typing</button>
        </div>
      </div>
    </div>
  `;

  // Isolate dialog from website event listeners
  const isolatedEvents = ["keydown", "keyup", "keypress", "contextmenu", "copy", "paste", "cut", "mousedown", "mouseup"];
  isolatedEvents.forEach((evt) => {
    dialogOverlay.addEventListener(evt, (e) => e.stopPropagation(), true);
  });

  // Vocabulary Helper Elements
  const defineBadge = document.createElement("div");
  defineBadge.id = "fp-define-badge";
  defineBadge.innerHTML = `
    <svg viewBox="0 0 24 24"><path d="M18 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM6 4h5v8l-2.5-1.5L6 12V4z"/></svg>
    <span>Define</span>
  `;

  const vocabCard = document.createElement("div");
  vocabCard.id = "fp-vocab-card";
  vocabCard.innerHTML = `
    <div class="fp-card-header">
      <div class="fp-card-title-row">
        <button class="fp-speaker-btn" title="Pronounce word" id="fp-card-speaker">
          <svg viewBox="0 0 24 24"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/></svg>
        </button>
        <div>
          <span class="fp-word-title" id="fp-card-word">word</span>
          <span class="fp-word-phonetic" id="fp-card-phonetic">/phonetic/</span>
        </div>
      </div>
      <button class="fp-close-btn" id="fp-card-close">&times;</button>
    </div>
    <div id="fp-card-content">
      <div style="color:#94a3b8;padding:8px 0;">Looking up definitions & synonyms...</div>
    </div>
  `;

  shadow.appendChild(style);
  shadow.appendChild(container);
  shadow.appendChild(dialogOverlay);
  shadow.appendChild(defineBadge);
  shadow.appendChild(vocabCard);

  const mountHost = () => {
    if (!document.documentElement.contains(host)) {
      (document.body || document.documentElement).appendChild(host);
    }
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", mountHost);
  } else {
    mountHost();
  }

  function isEditable(el) {
    if (!el || el.disabled || el.readOnly) return false;
    if (el instanceof HTMLTextAreaElement) return true;
    if (el instanceof HTMLInputElement) {
      const excluded = ["button", "checkbox", "color", "file", "hidden", "image", "radio", "range", "reset", "submit"];
      return !excluded.includes((el.type || "").toLowerCase());
    }
    return el.isContentEditable || el.getAttribute("contenteditable") === "true";
  }

  function updateButtonPosition(target) {
    if (!target || !document.contains(target)) {
      hideButton();
      return;
    }

    const rect = target.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) {
      hideButton();
      return;
    }

    const scrollX = window.scrollX || window.pageXOffset || 0;
    const scrollY = window.scrollY || window.pageYOffset || 0;

    const isSmall = rect.height < 32 || rect.width < 120;
    let top, left;

    if (isSmall) {
      top = scrollY + rect.top - 30;
      if (top < scrollY + 4) top = scrollY + rect.bottom + 4;
      left = scrollX + rect.right - 85;
    } else {
      top = scrollY + rect.top + 3;
      left = scrollX + rect.right - 90;
    }

    if (left < scrollX + 4) left = scrollX + 4;

    container.style.top = `${top}px`;
    container.style.left = `${left}px`;
    container.classList.add("ht-visible");
  }

  function hideButton() {
    container.classList.remove("ht-visible");
  }

  document.addEventListener(
    "focusin",
    (e) => {
      if (dialogOverlay.style.display === "flex") return;
      if (e.target && isEditable(e.target)) {
        activeElement = e.target;
        if (hideTimeout) clearTimeout(hideTimeout);
        if (settings.enabled && settings.showFloatingIcon && !isTyping) {
          mountHost();
          updateButtonPosition(activeElement);
        }
      }
    },
    true
  );

  document.addEventListener(
    "focusout",
    (e) => {
      hideTimeout = setTimeout(() => {
        if (!isTyping && dialogOverlay.style.display !== "flex") {
          hideButton();
        }
      }, 350);
    },
    true
  );

  window.addEventListener(
    "scroll",
    () => {
      if (activeElement && container.classList.contains("ht-visible")) {
        requestAnimationFrame(() => updateButtonPosition(activeElement));
      }
    },
    { passive: true }
  );

  window.addEventListener(
    "resize",
    () => {
      if (activeElement && container.classList.contains("ht-visible")) {
        requestAnimationFrame(() => updateButtonPosition(activeElement));
      }
    },
    { passive: true }
  );

  container.addEventListener("mousedown", (e) => {
    e.preventDefault();
    if (hideTimeout) clearTimeout(hideTimeout);
  });

  // Typing engine
  async function typeTextIntoElement(target, text) {
    if (!target || !text) return;
    isTyping = true;
    abortTyping = false;

    pasteBtn.classList.add("ht-stop");
    pasteBtn.innerHTML = `
      <svg viewBox="0 0 24 24"><path d="M6 6h12v12H6z"/></svg>
      <span class="ht-label">Stop</span>
    `;

    try {
      target.focus();

      let baseDelay = 200;
      const wpm = parseInt(settings.customWPM, 10) || 60;

      if (settings.speedMode === "instant") {
        baseDelay = 0;
      } else if (settings.speedMode === "custom") {
        baseDelay = Math.round(12000 / Math.max(10, Math.min(600, wpm)));
      } else if (settings.speedMode === "fast") {
        baseDelay = 12;
      } else if (settings.speedMode === "human") {
        baseDelay = 220;
      }

      for (let i = 0; i < text.length; i++) {
        if (abortTyping) break;

        const char = text[i];
        insertSingleCharacter(target, char);

        if (settings.speedMode === "instant") continue;

        let delay = baseDelay;
        if (settings.naturalJitter) {
          const variance = baseDelay * 0.25;
          const jitter = (Math.random() * variance * 2) - variance;
          delay = Math.max(5, delay + jitter);

          if (char === " ") delay += baseDelay * 0.2;
          else if ([".", ",", "!", "?", ";", ":", "\n"].includes(char)) delay += baseDelay * 0.5;

          if (i > 0 && i % 25 === 0 && Math.random() > 0.4) delay += baseDelay * 0.8;
        }

        await new Promise((r) => setTimeout(r, Math.max(5, delay)));
      }

      target.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
    } finally {
      isTyping = false;
      abortTyping = false;
      pasteBtn.classList.remove("ht-stop");
      pasteBtn.innerHTML = `
        <svg viewBox="0 0 24 24"><path d="M19 2h-4.18C14.4 0.84 13.3 0 12 0c-1.3 0-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-7 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm7 18H5V4h2v3h10V4h2v16z"/></svg>
        <span class="ht-label">ForcePaste</span>
      `;
      if (activeElement) {
        updateButtonPosition(activeElement);
      }
    }
  }

  function insertSingleCharacter(target, char) {
    const code = char.length === 1 ? `Key${char.toUpperCase()}` : "Enter";
    const keyCode = char.charCodeAt(0);

    target.dispatchEvent(
      new KeyboardEvent("keydown", {
        key: char,
        code: code,
        keyCode: keyCode,
        which: keyCode,
        charCode: keyCode,
        bubbles: true,
        composed: true,
        cancelable: true
      })
    );

    target.dispatchEvent(
      new InputEvent("beforeinput", {
        bubbles: true,
        composed: true,
        cancelable: true,
        inputType: "insertText",
        data: char
      })
    );

    let inserted = false;
    try {
      inserted = document.execCommand("insertText", false, char);
    } catch (e) {
      inserted = false;
    }

    if (!inserted && (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement)) {
      const start = target.selectionStart ?? target.value.length;
      const end = target.selectionEnd ?? target.value.length;
      const val = target.value;
      const nextVal = val.slice(0, start) + char + val.slice(end);

      const proto = Object.getPrototypeOf(target);
      const descriptor = Object.getOwnPropertyDescriptor(proto, "value");
      if (descriptor && descriptor.set) {
        descriptor.set.call(target, nextVal);
      } else {
        target.value = nextVal;
      }

      const nextPos = start + char.length;
      if (typeof target.setSelectionRange === "function") {
        target.setSelectionRange(nextPos, nextPos);
      }

      target.dispatchEvent(
        new InputEvent("input", {
          bubbles: true,
          composed: true,
          inputType: "insertText",
          data: char
        })
      );
    } else if (!inserted && target.isContentEditable) {
      const sel = window.getSelection();
      if (sel && sel.rangeCount > 0) {
        const range = sel.getRangeAt(0);
        range.deleteContents();
        const textNode = document.createTextNode(char);
        range.insertNode(textNode);
        range.setStartAfter(textNode);
        range.collapse(true);
        sel.removeAllRanges();
        sel.addRange(range);
        target.dispatchEvent(
          new InputEvent("input", {
            bubbles: true,
            composed: true,
            inputType: "insertText",
            data: char
          })
        );
      }
    }

    target.dispatchEvent(
      new KeyboardEvent("keyup", {
        key: char,
        code: code,
        keyCode: keyCode,
        which: keyCode,
        charCode: keyCode,
        bubbles: true,
        composed: true,
        cancelable: true
      })
    );
  }

  async function fetchClipboardText() {
    try {
      const resp = await chrome.runtime.sendMessage({ type: "READ_CLIPBOARD_BG" });
      if (resp && typeof resp.text === "string" && resp.text.length > 0) {
        return resp.text;
      }
    } catch (err) {}

    try {
      const text = await navigator.clipboard.readText();
      if (text) return text;
    } catch (err) {}

    return "";
  }

  async function performPaste() {
    if (isTyping) {
      abortTyping = true;
      return;
    }

    const target = activeElement || (isEditable(document.activeElement) ? document.activeElement : null);
    if (!target) return;

    const text = await fetchClipboardText();
    if (text) {
      await typeTextIntoElement(target, text);
    } else {
      showFallbackDialog(target);
    }
  }

  function showFallbackDialog(target) {
    const textarea = dialogOverlay.querySelector("#ht-modal-textarea");
    const fetchBtn = dialogOverlay.querySelector("#ht-btn-fetch-clip");
    const cancelBtn = dialogOverlay.querySelector(".ht-btn-cancel");
    const confirmBtn = dialogOverlay.querySelector(".ht-btn-confirm");

    textarea.value = "";
    dialogOverlay.style.display = "flex";
    setTimeout(() => textarea.focus(), 60);

    const close = () => {
      dialogOverlay.style.display = "none";
      if (target) target.focus();
    };

    fetchBtn.onclick = async (e) => {
      e.stopPropagation();
      const clipText = await fetchClipboardText();
      if (clipText) {
        textarea.value = clipText;
      } else {
        fetchBtn.textContent = "Clipboard empty!";
        setTimeout(() => {
          fetchBtn.innerHTML = `
            <svg style="width:12px;height:12px;fill:currentColor" viewBox="0 0 24 24"><path d="M19 2h-4.18C14.4 0.84 13.3 0 12 0c-1.3 0-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/></svg>
            Paste from Clipboard
          `;
        }, 1500);
      }
    };

    cancelBtn.onclick = (e) => {
      e.stopPropagation();
      close();
    };

    confirmBtn.onclick = (e) => {
      e.stopPropagation();
      const text = textarea.value;
      close();
      if (text && target) {
        typeTextIntoElement(target, text);
      }
    };
  }

  pasteBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    performPaste();
  });

  document.addEventListener(
    "keydown",
    (e) => {
      if (e.altKey && (e.key === "v" || e.key === "V" || e.code === "KeyV")) {
        const target = isEditable(document.activeElement) ? document.activeElement : activeElement;
        if (target) {
          e.preventDefault();
          e.stopPropagation();
          activeElement = target;
          performPaste();
        }
      }
    },
    true
  );

  // =========================================================================
  // 4TH FEATURE: VOCABULARY / THESAURUS HELPER IMPLEMENTATION
  // =========================================================================

  let currentAudioUrl = null;

  function pronounceWord(word) {
    if (currentAudioUrl) {
      const audio = new Audio(currentAudioUrl);
      audio.play().catch(() => speakWord(word));
    } else {
      speakWord(word);
    }
  }

  function speakWord(word) {
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      const utter = new SpeechSynthesisUtterance(word);
      utter.lang = "en-US";
      window.speechSynthesis.speak(utter);
    }
  }

  async function fetchWordDetails(word) {
    let result = {
      word: word,
      phonetic: "",
      audioUrl: null,
      definitions: [],
      synonyms: []
    };

    try {
      const res = await fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(word)}`);
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data) && data.length > 0) {
          const entry = data[0];
          result.phonetic = entry.phonetic || (entry.phonetics?.find((p) => p.text)?.text) || "";
          result.audioUrl = entry.phonetics?.find((p) => p.audio)?.audio || null;

          if (entry.meanings) {
            entry.meanings.forEach((m) => {
              const part = m.partOfSpeech || "";
              m.definitions?.slice(0, 2).forEach((d) => {
                result.definitions.push({
                  partOfSpeech: part,
                  definition: d.definition,
                  example: d.example || ""
                });
              });
              if (m.synonyms) {
                result.synonyms.push(...m.synonyms);
              }
            });
          }
        }
      }
    } catch (e) {}

    // Datamuse API fallback / supplement for rich synonyms
    if (result.synonyms.length < 5) {
      try {
        const dmRes = await fetch(`https://api.datamuse.com/words?rel_syn=${encodeURIComponent(word)}&max=15`);
        if (dmRes.ok) {
          const dmData = await dmRes.json();
          if (Array.isArray(dmData)) {
            const extraSyns = dmData.map((item) => item.word);
            result.synonyms = Array.from(new Set([...result.synonyms, ...extraSyns]));
          }
        }
      } catch (e) {}
    }

    return result;
  }

  async function showVocabModal(word, x, y) {
    mountHost();
    selectedWord = word;
    currentAudioUrl = null;

    const wordEl = shadow.querySelector("#fp-card-word");
    const phoneticEl = shadow.querySelector("#fp-card-phonetic");
    const contentEl = shadow.querySelector("#fp-card-content");

    wordEl.textContent = word;
    phoneticEl.textContent = "...";
    contentEl.innerHTML = `<div style="color:#94a3b8;padding:12px 0;">Searching Oxford definitions & synonyms...</div>`;

    // Position modal safely within viewport
    const modalWidth = 330;
    let left = Math.min(Math.max(10, x), window.innerWidth - modalWidth - 20) + window.scrollX;
    let top = y + window.scrollY;

    vocabCard.style.left = `${left}px`;
    vocabCard.style.top = `${top}px`;
    vocabCard.style.display = "block";
    defineBadge.style.display = "none";

    const data = await fetchWordDetails(word);
    phoneticEl.textContent = data.phonetic || "";
    currentAudioUrl = data.audioUrl;

    let html = "";

    if (data.definitions.length > 0) {
      html += `<div class="fp-section-title"><span>Definitions</span><span style="font-size:10px;color:#94a3b8;">${data.definitions.length} found</span></div>`;
      data.definitions.slice(0, 3).forEach((d) => {
        html += `
          <div class="fp-definition-item">
            <span class="fp-part-of-speech">${d.partOfSpeech}</span>
            ${d.definition}
            ${d.example ? `<div class="fp-example">"${d.example}"</div>` : ""}
          </div>
        `;
      });
    } else {
      html += `<div style="color:#94a3b8;margin-bottom:8px;">No direct dictionary definition found.</div>`;
    }

    if (data.synonyms.length > 0) {
      html += `
        <div class="fp-section-title">
          <span>Synonyms</span>
          <span style="font-size:10px;color:#94a3b8;">Click to copy / replace</span>
        </div>
        <div class="fp-synonyms-wrap">
      `;
      data.synonyms.slice(0, 16).forEach((s) => {
        html += `<span class="fp-synonym-pill" data-syn="${s}">${s}</span>`;
      });
      html += `</div>`;
    }

    contentEl.innerHTML = html;

    // Attach click listeners to synonyms
    contentEl.querySelectorAll(".fp-synonym-pill").forEach((pill) => {
      pill.addEventListener("click", (e) => {
        e.stopPropagation();
        const syn = pill.dataset.syn;
        navigator.clipboard.writeText(syn);
        pill.textContent = `✓ Copied!`;
        pill.style.background = "#10b981";
        pill.style.borderColor = "#10b981";
        pill.style.color = "#ffffff";

        // If active field is focused, replace selected text
        if (activeElement && isEditable(activeElement)) {
          insertSingleCharacter(activeElement, syn);
        }

        setTimeout(() => {
          pill.textContent = syn;
          pill.style.background = "#1e293b";
          pill.style.borderColor = "#3b82f6";
          pill.style.color = "#93c5fd";
        }, 1200);
      });
    });
  }

  // Audio pronunciation button click
  shadow.querySelector("#fp-card-speaker").addEventListener("click", (e) => {
    e.stopPropagation();
    if (selectedWord) pronounceWord(selectedWord);
  });

  // Close vocab modal
  shadow.querySelector("#fp-card-close").addEventListener("click", (e) => {
    e.stopPropagation();
    vocabCard.style.display = "none";
  });

  // Handle Text Selection for Floating "Define" Badge
  document.addEventListener("mouseup", (e) => {
    if (!settings.vocabHelper) return;

    // Ignore clicks inside our shadow DOM
    if (host.contains(e.target)) return;

    setTimeout(() => {
      const selection = window.getSelection();
      const text = selection ? selection.toString().trim() : "";

      // Trigger on 1 to 3 words (typical vocabulary range)
      if (text && text.length >= 2 && text.length <= 40 && !text.includes("\n")) {
        const words = text.split(/\s+/);
        if (words.length <= 3) {
          try {
            const range = selection.getRangeAt(0);
            const rect = range.getBoundingClientRect();
            if (rect.width > 0 && rect.height > 0) {
              const x = rect.left + rect.width / 2 - 30 + window.scrollX;
              const y = rect.bottom + 6 + window.scrollY;

              defineBadge.style.left = `${Math.max(10, x)}px`;
              defineBadge.style.top = `${y}px`;
              defineBadge.style.display = "flex";

              defineBadge.onclick = (evt) => {
                evt.stopPropagation();
                showVocabModal(text, rect.left, rect.bottom + 10);
              };
              return;
            }
          } catch (err) {}
        }
      }

      defineBadge.style.display = "none";
    }, 60);
  });

  // Close floating card when clicking outside
  document.addEventListener("mousedown", (e) => {
    if (!host.contains(e.target)) {
      vocabCard.style.display = "none";
      defineBadge.style.display = "none";
    }
  });
})();
